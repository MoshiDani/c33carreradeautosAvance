# PROC41-1_4-referencia-maestra1
## Referencia de la maestra 1 para la clase 41 nivel PRO 1-4.
Solución de la actividad (cámara de juego).

### Nombre en inglés: Multiplayer-stage-5-final
C37-SpeedRacer_ReferenceCode

Fin de Etapa 5. 
